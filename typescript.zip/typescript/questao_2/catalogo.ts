import { filme } from "./filme";
export class catalogo {
    private filme:string[] = [] ;

    adicionarFilme(filme: Filme){
        filmes.forEach(filme) =>{   
        }
    listarFilmes()
    }
}