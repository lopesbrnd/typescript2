import { catalogo } from "./catalogo";
import { filme } from "./filme";
function filtrarFilmesPorAno(filmes: Filme[], ano: number): Filme[]
let filme1 = new filme('A Origem', 'Christopher Nolan', 2010)