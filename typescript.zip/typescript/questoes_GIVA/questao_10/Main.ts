import { Carro } from './Carro';

const carro1 = new Carro('Toyota', 'Corolla', 2021);
console.log(`Carro 1: Marca: ${carro1.marca}, Modelo: ${carro1.modelo}, Ano: ${carro1.ano}`);

const carro2 = new Carro('Honda', 'Civic');
console.log(`Carro 2: Marca: ${carro2.marca}, Modelo: ${carro2.modelo}, Ano: ${carro2.ano}`);
